import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard 
        firstName={"Jane"} 
        lastName={"Doe"} 
        initialAge={45} 
        hairColor={"Black"}/>
      <PersonCard 
        firstName={"Smith"} 
        lastName={"John"} 
        initialAge={88}
        hairColor={"Brown"}/>
      <PersonCard 
        firstName={"Fillmore"} 
        lastName={"Millard"} 
        initialAge={50} 
        hairColor={"Brown"}/>
      <PersonCard 
        firstName={"Smith"} 
        lastName={"Maria"} 
        initialAge={62} 
        hairColor={"Brown"}/>
      
    </div>
  );
}

export default App;
