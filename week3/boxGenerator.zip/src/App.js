import BoxColorForm from './components/BoxColorForm';
import './App.css';
import Display from './components/Display';
import { useState } from 'react';

function App() {
  const [boxColorArray,setBoxColorArray] = useState([])
  
  return (
    <div className="App">
      <h1>Box Generator Assignment</h1>
      <BoxColorForm boxColorArray={boxColorArray} setBoxColorArray={setBoxColorArray}/>
      <Display boxColorArray={boxColorArray}/>
    </div>
  );
}

export default App;
