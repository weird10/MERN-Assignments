import React, {useState} from 'react'
import '../App.css'


const BoxColorForm = (props) => {
    const {boxColorArray, setBoxColorArray} = props
    const [ color, setColor] = useState('')
    const [ size, setSize ] = useState(100)
    

    const submitHandler = (e) => {
        e.preventDefault()
       setBoxColorArray([...boxColorArray,{
        color:color,
        size:size + "px",
    }])
       setColor('')
       setSize('')
    }


    return (
        <div>
                <h1>Box color input:</h1>
                <form onSubmit={submitHandler} >
                        <label>
                            Box color: 
                            <input type="text"  
                            onChange={ (e) => setColor(e.target.value) } value={color}/>
                        </label>
                        <label>
                            Box size: 
                            <input type="number"  
                            onChange={ (e) => setSize(e.target.value) } value={size}/>
                        </label>
                    <button>Box it up</button>
                </form>
            
        </div>
    )


}

export default BoxColorForm;