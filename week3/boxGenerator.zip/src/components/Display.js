import '../App.css'


const Display = (props) => {
    const {boxColorArray} = props
    return (
        <div>
            {
                boxColorArray.map((input, index) => (
                <div key={index} style= {{
                    display: "inline-block",
                    margin: "20px",
                    height: input.size,
                    width: input.size,
                    backgroundColor: input.color }}>
                </div>
            ))
            }
        </div>
    )
}

export default Display