import './App.css';
import Header from './components/Header';
import Main from './components/Main';
import Subcontent from './components/Subcontent';
import Advertisement from './components/Advertisement';
import Navigation from './components/Navigation';

function App() {
  return (
    <div className="App">
      <Header />
      <div className="body">
        <Navigation />
        <Main />
      </div>
    </div>
  );
}

export default App;
