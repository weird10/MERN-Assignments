import '../App.css';

const Advertisement = () => {
    return(
    <div className="advertisement">

    </div>
    )
}

export default Advertisement