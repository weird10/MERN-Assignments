import '../App.css';
import Advertisement from './Advertisement';
import Subcontent from './Subcontent';

const Main = () => {
    return(
    <div className="main">
        <div className="row">
        <Subcontent />
        <Subcontent />
        <Subcontent />
        </div>
        <Advertisement />
        
    </div>    
    )
}

export default Main