import '../App.css';

const Navigation = () => {
    return(
    <div className="navigation">
        
    </div>
    )
}



export default Navigation