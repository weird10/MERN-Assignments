import '../App.css';

const Subcontent = () => {
    return(
    <div className="subcontent">
    </div>
    )
}


export default Subcontent