import './App.css';
import { useState } from 'react';
import Form from './components/Form';
import Message from './components/Message';

function App() {
  const [newTodo, setNewTodo] = useState('')
  const [todoList ,setTodoList] = useState([])

  const handleSubmit = (e) => {
    e.preventDefault()
    setTodoList([...todoList, newTodo])
    setNewTodo('')
  }
  
  return (
    <div className="App"> 
      <form onSubmit={handleSubmit}>
        <input type='text' onChange={e=> setNewTodo(e.target.value)} />
      </form>
      {todoList.map((item, index) =>
      <Message />
      )}
      
    </div>
  );
}

export default App;
