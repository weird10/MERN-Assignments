import './App.css';
import { useState } from 'react';

function App() {
  const [newTodo, setNewTodo] = useState('')
  const [todoList ,setTodoList] = useState([])


  // what happens when we submit a to do
  const handleSubmit = (e) => {
    e.preventDefault()
    if(newTodo.length === 0)
    return
    // declaring whats inside a todo item
    const todoItem = {
      text: newTodo,
      complete: false
    }
    // pushing the new todoItem into the todoList by using setter
    setTodoList([...todoList, todoItem])
    setNewTodo('')
  }

  // to delete each item, delIndex is the reference we will get from the form.
  const deleteItem = (delIndex) => {
  
    // new array with the index of the item filtered out if it matches the index in our list.
    const filteredList = todoList.filter((todoList,index) => {
      return delIndex !== index
    })

    // save our todoList with the new filtered list
    setTodoList(filteredList)
  }

  // // to indicate that it is complete by a checkbox
  const handleComplete = (itemIndex) => {
    
    // creating a copy of the todoList but pushing in the index as well to check if we can find the index of the todoItem that is in our list. 
    const updatedTodoList = todoList.map((todo, index) => {
      // if it matches one of the index, it will carry on to the next step
      if(itemIndex === index) {
    // creating a new array of task and updating complete true or false and then return the new array
        const updatedTodos = { ...todo, complete: !todo.complete}  
        return updatedTodos
        //
      }
      return todo
      })
      return(
      setTodoList(updatedTodoList)
      )
      // update our todoList with the updated complete value
      
    }
  

  return (
    <div className="App"> 
      <form onSubmit={handleSubmit}>
        <label>
          New To-Do item:
          <input type='text' onChange={e=> setNewTodo(e.target.value)} value={newTodo} />
        </label>
        <input type="submit" value="Add" />
      </form>

      {todoList.map((item, index) => {
        const todoClass = ["bold"]

        if (item.complete) {
          todoClass.push("line-through")
        }
        return (
        <div className="row" key={index}>
          <input onChange={(e) => { 
            handleComplete(index)
                }} checked={item.complete} type="checkbox">
            
          </input>
          <p className={todoClass.join(" ")}>{item.text}</p>
          <button onClick={e=>deleteItem(index)}>Delete</button>
        </div> 
            )
        }
      )}
      
    </div>
  );
}

export default App
