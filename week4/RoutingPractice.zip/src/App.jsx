import {BrowserRouter, Routes, Route} from 'react-router-dom'
import './App.css';
import Home from './components/Home';
import InputParam from './components/InputParam';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <Routes>
        <Route element={< Home />} path="/home" />
        <Route element={< InputParam/>} path="/:word" />
        <Route element={< InputParam/>} path="/:word/:color/:bgColor" />
      </Routes>
    </div>
      </BrowserRouter>
  );
}

export default App;
