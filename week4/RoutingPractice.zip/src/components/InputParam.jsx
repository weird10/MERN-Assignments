import {useParams} from 'react-router-dom'

const InputParam = (props) => {

    const {word, color, bgColor} = useParams()

    return (
        <div>
            { 
            isNaN(word)?
            <h2 style={
                color? 
                {color: color, backgroundColor:bgColor}
                :null
            }>
               This is a word ---> "{word}" 
            </h2>
            :
            <h2>
                This is a number ----> {word}
            </h2>
            }
        </div>
    )
}

export default InputParam