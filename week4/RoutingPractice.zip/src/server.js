const express = require('express')
const app = express()
const PORT = 3000


app.listen(PORT,()=>{
    console.log(`Hamburger is up and running on port: ${PORT}`)
})

const welcome = (props) => {
    return (
      <h1>Welcome!</h1>
    );
  }


app.get('/home',(req,res)=>{
    const greeting = welcome()
    res.json(greeting)

app.get('/:word', (req,res) => {
    const word = req.params.word
    res.json(word)
})

app.post('/:number', (req,res)=> {
    const number = req.params.word
    console.log(number)
})
})