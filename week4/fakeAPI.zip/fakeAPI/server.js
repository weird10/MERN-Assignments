const express = require('express')
const app = express()
const PORT = 8000

const { faker } = require('@faker-js/faker')

app.listen(PORT,()=>{
    console.log(`Server is up and running on port: ${PORT}`)
})



const createUser = () => {
    return {
        _id: faker.datatype.uuid(),
        first_name: faker.name.firstName(),
        last_name: faker.name.lastName(),
        email: faker.internet.email(),
        password: faker.internet.password(),
        phone_number:faker.phone.number()
    }
}
const createCompany = () => {
    return {
        _id: faker.datatype.uuid(),
        company: faker.company.name(),
        Address: {street: faker.address.street(), 
        city: faker.address.city(),
        state: faker.address.state(),
        zipCode: faker.address.zipCode(),
        country: faker.address.country(),}
    }
}


app.get('/api/users/new',(req,res)=>{
    const user=createUser()
    console.log(user)
    res.json(user)
})
    
    
    app.get('/api/company/new',(req,res)=>{
        const company= createCompany()
        console.log(company)
        res.json(company)
    })
    
    app.get('/api/user/company', (req,res)=> {
        const newCompany = createCompany()
        const newUser = createUser()
        const combinedResult = {
            user: newUser,
            company:newCompany
            
        }
        console.log(combinedResult)
        res.json(combinedResult)
        

})
