import './App.css';
import axios from 'axios';
import { useEffect, useState } from 'react';


function App() {
const [pokemon, setPokemon] = useState([])

const makeCall= async() => {
  try {
    const results = await axios.get('https://pokeapi.co/api/v2/pokemon')
    setPokemon(results.data.results)
    console.log(results)
  } catch(error) {
    console.log(error)
  }
}

useEffect (() => {
  makeCall()
}, [])


  return (
    <div className="App">
      <ul>
    {
    pokemon.map((poke, index) => (
      <ul>
        <li key={index}>{poke.name}</li>
      </ul>
      
    ))}
    </ul>
    </div>
  );
}


export default App;
