const mongoose = require('mongoose');
 
const JokeSchema = new mongoose.Schema({
    setup: {
        type: String,
        required: [true, "Setup is required"],
        minlength: [5, "Setup must be at least 5 characters or longer"]
    },
    punchline: {
        type: String,
        required: [true, "punchline is required"],
        minlength: [5, "Punchline must be at least 5 characters or longer"]
    }

});
 
const Joke = mongoose.model('joke', JokeSchema);
 
module.exports = Joke;

